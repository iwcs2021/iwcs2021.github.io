"""
Reorganize the decoding file to be in order and have one result per line.
Also merge results into a single multi-sentence result if they aren't 
connected.
"""

from amr_parser import *

