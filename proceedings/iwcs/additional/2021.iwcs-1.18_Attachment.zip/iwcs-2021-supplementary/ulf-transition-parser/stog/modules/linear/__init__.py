from stog.modules.linear.bilinear import BiLinear
