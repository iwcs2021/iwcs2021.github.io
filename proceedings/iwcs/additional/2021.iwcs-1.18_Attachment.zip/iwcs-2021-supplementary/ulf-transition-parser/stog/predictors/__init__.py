from stog.predictors.predictor import Predictor
from stog.predictors.stog import STOGPredictor
