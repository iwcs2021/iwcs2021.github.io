
cd tools
wget http://nlp.stanford.edu/software/stanford-corenlp-full-2018-10-05.zip
module load unzip
unzip stanford-corenlp-full-2018-10-05.zip
rm stanford-corenlp-full-2018-10-05.zip
cd ..

