Gene Louis Kim's Lisp Utilities.
Started ~2018-11-15

This directory is library a general utility functions in common lisp, such as
file IO, string manipulation, etc.  This code is not all written by me.  Much
of the code is copied over (and refactored) from the Lore project by Benjamin
Van Durme and Jonathan Gordon.  I made an effort to include comments to give
credit appropriately, but I don't promise I got every case. 

The files are named to reflect the content inside.  Please read the comments in
the files to get the details.

