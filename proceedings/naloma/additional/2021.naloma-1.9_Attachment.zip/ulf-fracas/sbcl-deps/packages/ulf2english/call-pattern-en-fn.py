
from pattern.en import *
import sys

# For some reason these aren't defined in pattern.en
IMPERFECTIVE='imperfective'
PERFECTIVE='perfective'

sys.stdout.write(eval(sys.argv[1]))


